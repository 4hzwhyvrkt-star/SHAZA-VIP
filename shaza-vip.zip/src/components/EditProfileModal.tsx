/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Save, AlertCircle } from 'lucide-react';
import { CreatorProfile, Language } from '../types';
import { translations } from '../utils/translations';

interface EditProfileModalProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onSave: (profile: CreatorProfile) => void;
  currentProfile: CreatorProfile;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  language,
  isOpen,
  onClose,
  onSave,
  currentProfile
}) => {
  const t = translations[language];

  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [verified, setVerified] = useState(true);
  const [errorWord, setErrorWord] = useState('');

  useEffect(() => {
    if (currentProfile) {
      setDisplayName(currentProfile.displayName);
      setUsername(currentProfile.username);
      setBio(currentProfile.bio);
      setAvatarUrl(currentProfile.avatarUrl);
      setCoverUrl(currentProfile.coverUrl);
      setVerified(currentProfile.verified);
    }
    setErrorWord('');
  }, [currentProfile, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorWord('');

    if (!displayName.trim() || !username.trim() || !bio.trim()) {
      setErrorWord(t.requiredField);
      return;
    }

    const updated: CreatorProfile = {
      displayName: displayName.trim(),
      username: username.trim().toLowerCase().replace(/\s+/g, ''),
      bio: bio.trim(),
      avatarUrl: avatarUrl.trim(),
      coverUrl: coverUrl.trim(),
      verified,
      views: currentProfile.views // retain existing views
    };

    onSave(updated);
    onClose();
  };

  const isRtl = language === 'ckb';

  return (
    <div id="edit-profile-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
      <motion.div
        id="edit-profile-modal-box"
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', duration: 0.4 }}
        className="w-full max-w-lg overflow-hidden rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col"
        style={{ direction: isRtl ? 'rtl' : 'ltr' }}
      >
        {/* Header toolbar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-850 bg-slate-900">
          <h2 className="text-lg font-bold text-slate-100">
            {t.editProfile}
          </h2>
          <button
            id="btn-close-profile-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form panel body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[75vh] flex flex-col gap-4">
          {errorWord && (
            <div id="profile-form-error-banner" className="flex items-center gap-2 p-3.5 rounded-xl bg-rose-950/60 border border-rose-900/50 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorWord}</span>
            </div>
          )}

          {/* Display Name & Username fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.displayName} *
              </label>
              <input
                id="input-profile-displayName"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Sparda Gaming"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.username} *
              </label>
              <input
                id="input-profile-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="spardagaming"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans text-left"
                style={{ direction: 'ltr' }}
                required
              />
            </div>
          </div>

          {/* Avatar and Cover URLs */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.avatarUrl}
            </label>
            <input
              id="input-profile-avatarUrl"
              type="url"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans text-left"
              style={{ direction: 'ltr' }}
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.coverUrl}
            </label>
            <input
              id="input-profile-coverUrl"
              type="url"
              value={coverUrl}
              onChange={(e) => setCoverUrl(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans text-left"
              style={{ direction: 'ltr' }}
            />
          </div>

          {/* Creator Bio summary text area */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.bio} *
            </label>
            <textarea
              id="input-profile-bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Write a creative profile biography..."
              rows={4}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans resize-none"
              required
            />
          </div>

          {/* Switch Verified status toggler */}
          <div className="flex items-center gap-3 bg-slate-950 p-4 rounded-xl border border-slate-850 select-none">
            <input
              id="checkbox-profile-verified"
              type="checkbox"
              checked={verified}
              onChange={(e) => setVerified(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-850 focus:ring-indigo-500 focus:ring-2 cursor-pointer"
            />
            <label htmlFor="checkbox-profile-verified" className="text-xs font-semibold text-slate-300 cursor-pointer">
              {t.verified}
            </label>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 border-t border-slate-850 pt-4 mt-2">
            <button
              id="btn-profile-form-cancel"
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-850 text-sm font-medium transition-colors cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              id="btn-profile-form-submit"
              type="submit"
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-500/10 hover:shadow-indigo-500/20 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{t.saveChanges}</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
