/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Save, AlertCircle } from 'lucide-react';
import { Channel, Language, Category } from '../types';
import { translations } from '../utils/translations';

interface AddChannelModalProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onSave: (channel: Channel) => void;
  editingChannel: Channel | null;
  categories: Category[];
}

const COLOR_PRESETS = [
  { hex: '#EF4444', name: 'Red' },
  { hex: '#3B82F6', name: 'Telegram Blue' },
  { hex: '#EC4899', name: 'Hot Pink' },
  { hex: '#8B5CF6', name: 'Twitch Purple' },
  { hex: '#5865F2', name: 'Discord Blurple' },
  { hex: '#F43F5E', name: 'Rose' },
  { hex: '#10B981', name: 'Green' },
  { hex: '#F59E0B', name: 'Amber' },
  { hex: '#475569', name: 'Slate' }
];

const PLATFORMS = [
  { id: 'youtube', label: 'YouTube' },
  { id: 'telegram', label: 'Telegram' },
  { id: 'tiktok', label: 'TikTok' },
  { id: 'twitch', label: 'Twitch' },
  { id: 'instagram', label: 'Instagram' },
  { id: 'facebook', label: 'Facebook' },
  { id: 'discord', label: 'Discord' },
  { id: 'snapchat', label: 'Snapchat' },
  { id: 'twitter', label: 'Twitter / X' },
  { id: 'website', label: 'Website/Other' }
];

export const AddChannelModal: React.FC<AddChannelModalProps> = ({
  language,
  isOpen,
  onClose,
  onSave,
  editingChannel,
  categories
}) => {
  const t = translations[language];
  
  // Local states matching Form Parameters
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [handle, setHandle] = useState('');
  const [platform, setPlatform] = useState<Channel['platform']>('youtube');
  const [category, setCategory] = useState('gaming');
  const [accentColor, setAccentColor] = useState('#EF4444');
  const [description, setDescription] = useState('');
  
  // Validation messages state
  const [errorWord, setErrorWord] = useState('');

  // Sync editing fields with initial values
  useEffect(() => {
    if (editingChannel) {
      setName(editingChannel.name);
      setUrl(editingChannel.url);
      setHandle(editingChannel.handle);
      setPlatform(editingChannel.platform);
      setCategory(editingChannel.category);
      setAccentColor(editingChannel.accentColor);
      setDescription(editingChannel.description);
    } else {
      // Default clean slate values
      setName('');
      setUrl('');
      setHandle('');
      setPlatform('youtube');
      setCategory('gaming');
      setAccentColor('#8B5CF6');
      setDescription('');
    }
    setErrorWord('');
  }, [editingChannel, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorWord('');

    // Pre-validation checks
    if (!name.trim() || !url.trim() || !handle.trim()) {
      setErrorWord(t.requiredField);
      return;
    }

    // URL format verification checklist
    try {
      const parsedUrl = new URL(url);
      if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
        setErrorWord(t.invalidUrl);
        return;
      }
    } catch (_) {
      setErrorWord(t.invalidUrl);
      return;
    }

    const payload: Channel = {
      id: editingChannel ? editingChannel.id : `ch-${Date.now()}`,
      name: name.trim(),
      url: url.trim(),
      handle: handle.trim(),
      platform,
      category,
      accentColor,
      description: description.trim(),
      clicks: editingChannel ? editingChannel.clicks : 0
    };

    onSave(payload);
    onClose();
  };

  const isRtl = language === 'ckb';

  return (
    <div id="modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
      <motion.div
        id="modal-box"
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', duration: 0.4 }}
        className="w-full max-w-lg overflow-hidden rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col"
        style={{ direction: isRtl ? 'rtl' : 'ltr' }}
      >
        {/* Modal Header bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-850 bg-slate-900">
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <span>{editingChannel ? t.editChannel : t.addChannel}</span>
          </h2>
          <button
            id="btn-close-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[75vh] flex flex-col gap-4">
          {errorWord && (
            <div id="form-error-banner" className="flex items-center gap-2 p-3.5 rounded-xl bg-rose-950/60 border border-rose-900/50 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorWord}</span>
            </div>
          )}

          {/* Line 1: Basic Name & Platform selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.channelName} *
              </label>
              <input
                id="input-channel-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="YouTube Channel / My Telegram"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.platform} *
              </label>
              <select
                id="select-channel-platform"
                value={platform}
                onChange={(e) => setPlatform(e.target.value as Channel['platform'])}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 outline-none text-sm cursor-pointer font-sans"
              >
                {PLATFORMS.map((p) => (
                  <option key={p.id} value={p.id}>{p.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Line 2: URL & Handle/Username details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.channelUrl} *
              </label>
              <input
                id="input-channel-url"
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans text-left"
                style={{ direction: 'ltr' }}
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {t.channelHandle} *
              </label>
              <input
                id="input-channel-handle"
                type="text"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                placeholder="@username"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans text-left"
                style={{ direction: 'ltr' }}
                required
              />
            </div>
          </div>

          {/* Line 3: Category category allocation */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.channelCategory}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {categories.filter(c => c.id !== 'all').map((cat) => (
                <button
                  id={`btn-select-category-${cat.id}`}
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                    category === cat.id
                      ? 'bg-indigo-950/80 border-indigo-500 text-indigo-300 shadow-md'
                      : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {isRtl ? cat.labelCkb : cat.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Line 4 Accent Color Palette selector */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-300">
              {t.accentColor}
            </label>
            <div className="flex flex-wrap gap-2.5 items-center bg-slate-950 p-3 rounded-xl border border-slate-850">
              {COLOR_PRESETS.map((color) => (
                <button
                  id={`btn-color-preset-${color.hex}`}
                  key={color.hex}
                  type="button"
                  onClick={() => setAccentColor(color.hex)}
                  className="w-7 h-7 rounded-lg border border-slate-800 flex items-center justify-center shrink-0 transition-all hover:scale-110 cursor-pointer"
                  style={{ backgroundColor: color.hex }}
                  title={color.name}
                >
                  {accentColor === color.hex && (
                    <div className="w-2.5 h-2.5 rounded-full bg-white shadow-md" />
                  )}
                </button>
              ))}
              <input
                id="input-channel-custom-color"
                type="color"
                value={accentColor}
                onChange={(e) => setAccentColor(e.target.value)}
                className="w-8 h-8 rounded-lg bg-transparent border-none outline-none cursor-pointer shrink-0"
                title="Custom Color"
              />
            </div>
          </div>

          {/* Line 5 Description */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.description}
            </label>
            <textarea
              id="input-channel-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Write a brief custom details about this link channel..."
              rows={3}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 text-slate-100 border border-slate-850 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none text-sm transition-all font-sans resize-none"
            />
          </div>

          {/* Form Actions footer */}
          <div className="flex items-center justify-end gap-3 border-t border-slate-850 pt-4 mt-2">
            <button
              id="btn-form-cancel"
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-850 text-sm font-medium transition-colors cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              id="btn-form-submit"
              type="submit"
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-500/10 hover:shadow-indigo-500/20 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{t.saveChanges}</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
