/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle, 
  Settings, 
  Globe2, 
  Eye, 
  Link2, 
  MousePointerClick,
  UserCheck
} from 'lucide-react';
import { CreatorProfile, Language } from '../types';
import { translations } from '../utils/translations';

interface ProfileHeaderProps {
  profile: CreatorProfile;
  language: Language;
  setLanguage: (lang: Language) => void;
  isAdminMode: boolean;
  setIsAdminMode: (admin: boolean) => void;
  channelsCount: number;
  totalClicksCount: number;
  onEditProfile: () => void;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({
  profile,
  language,
  setLanguage,
  isAdminMode,
  setIsAdminMode,
  channelsCount,
  totalClicksCount,
  onEditProfile
}) => {
  const t = translations[language];
  const isCkb = language === 'ckb';

  return (
    <div id="profile-header-container" className="relative w-full rounded-3xl overflow-hidden bg-white/5 backdrop-blur-xl border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.4)] mb-8">
      {/* 1. Header Banner/Cover Image */}
      <div className="relative h-44 sm:h-56 md:h-64 w-full bg-slate-950/80 overflow-hidden">
        {profile.coverUrl ? (
          <img 
            id="profile-cover-image"
            src={profile.coverUrl} 
            alt="Cover Graphic" 
            className="w-full h-full object-cover opacity-60 transition-scale duration-700 hover:scale-105"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-r from-purple-900/30 via-indigo-950/20 to-blue-900/30 opacity-60" />
        )}
        
        {/* Subtle decorative overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050508] via-transparent to-transparent" />

        {/* Floating Controller Options: Language Picker */}
        <div className="absolute top-4 right-4 left-4 flex justify-between items-center z-10">
          {/* Language Selector */}
          <button
            id="btn-toggle-language"
            onClick={() => setLanguage(language === 'en' ? 'ckb' : 'en')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-100 hover:text-white transition-all cursor-pointer backdrop-blur-xl"
          >
            <Globe2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>{language === 'en' ? 'کوردی' : 'English'}</span>
          </button>
        </div>
      </div>

      {/* 2. Profile Info Section */}
      <div className="px-6 pb-6 pt-0 relative flex flex-col items-center text-center -mt-16 sm:-mt-20">
        <div className="relative group">
          <div className="absolute -inset-1 rounded-full bg-gradient-to-tr from-purple-500 via-indigo-500 to-blue-500 opacity-80 blur-md transition duration-500 group-hover:opacity-100" />
          <div className="relative p-1 rounded-full bg-gradient-to-tr from-purple-500 via-indigo-500 to-blue-500">
            {profile.avatarUrl ? (
              <img 
                id="profile-avatar-image"
                src={profile.avatarUrl} 
                alt={profile.displayName} 
                className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-[#050508] shadow-2xl"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-slate-900 border-4 border-[#050508] shadow-2xl flex items-center justify-center">
                <span className="text-3xl font-bold text-slate-400">SG</span>
              </div>
            )}
          </div>
          {profile.verified && (
            <span 
              id="profile-verified-badge"
              className="absolute bottom-1 right-1 sm:bottom-2 sm:right-2 bg-[#050508] p-[3px] rounded-full shadow-lg"
              title="Verified Creator"
            >
              <CheckCircle className="w-6 h-6 sm:w-7 sm:h-7 text-indigo-400 fill-[#050508]" />
            </span>
          )}
        </div>

        {/* Full Name & User Profile Name */}
        <div className="mt-5 flex flex-col items-center">
          <div className="flex items-center gap-1.5 justify-center flex-wrap">
            <h1 className="text-2xl sm:text-4.5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-slate-400">
              {profile.displayName}
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-indigo-300 font-mono mt-1.5 font-semibold select-all">
            @{profile.username}
          </p>
        </div>



        {/* Quick Edit Profile Bio Button (Only Visible when Admin Mode is True) */}
        {isAdminMode && (
          <button
            id="btn-edit-bio"
            onClick={onEditProfile}
            className="mt-4 text-xs flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-indigo-300 hover:text-indigo-200 font-semibold transition-all cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            <span>{t.editProfile}</span>
          </button>
        )}

        {/* 3. Metrics Visualiser Dashboard */}
        <div className="grid grid-cols-3 gap-3 md:gap-5 w-full max-w-xl mt-6 border-t border-white/5 pt-6">
          {/* Active links count */}
          <div className="flex flex-col items-center p-3 sm:p-4 rounded-2xl bg-white/5 border border-white/5 shadow-inner">
            <Link2 className="w-4.5 h-4.5 text-purple-400 mb-1" />
            <span className="text-base sm:text-xl font-bold font-mono text-white">
              {channelsCount}
            </span>
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase tracking-wide mt-0.5 font-semibold">
              {t.totalChannels}
            </span>
          </div>

          {/* Combined Click Counter */}
          <div className="flex flex-col items-center p-3 sm:p-4 rounded-2xl bg-white/5 border border-white/5 shadow-inner">
            <MousePointerClick className="w-4.5 h-4.5 text-indigo-400 mb-1" />
            <span className="text-base sm:text-xl font-bold font-mono text-white">
              {totalClicksCount}
            </span>
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase tracking-wide mt-0.5 font-semibold">
              {t.totalClicks}
            </span>
          </div>

          {/* Localized Static Views counter */}
          <div className="flex flex-col items-center p-3 sm:p-4 rounded-2xl bg-white/5 border border-white/5 shadow-inner">
            <Eye className="w-4.5 h-4.5 text-blue-400 mb-1" />
            <span className="text-base sm:text-xl font-bold font-mono text-white">
              {profile.views}
            </span>
            <span className="text-[10px] sm:text-xs text-slate-400 uppercase tracking-wide mt-0.5 font-semibold">
              {t.profileViews}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
