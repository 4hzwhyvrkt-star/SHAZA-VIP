/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Youtube, 
  Send as TelegramIcon,
  Video, // representation for TikTok
  Twitch, 
  Instagram, 
  Facebook, 
  MessageSquare, // represent Discord
  Globe, 
  Ghost, // represent Snapchat
  Twitter, 
  Link2,
  Copy,
  Check,
  QrCode,
  Trash2,
  Edit2,
  ArrowUpRight,
  MousePointerClick
} from 'lucide-react';
import { Channel, Language } from '../types';
import { translations } from '../utils/translations';
import { initialCategories } from '../utils/initialData';

interface ChannelCardProps {
  channel: Channel;
  language: Language;
  isAdminMode: boolean;
  onEdit: (channel: Channel) => void;
  onDelete: (id: string) => void;
  onTrackClick: (id: string, url: string) => void;
}

export const ChannelCard: React.FC<ChannelCardProps> = ({
  channel,
  language,
  isAdminMode,
  onEdit,
  onDelete,
  onTrackClick
}) => {
  const [copied, setCopied] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const t = translations[language];

  const categoryObj = initialCategories.find(cat => cat.id === channel.category);
  const displayCategory = categoryObj 
    ? (language === 'ckb' ? categoryObj.labelCkb : categoryObj.labelEn) 
    : channel.category;

  // Helper to map platform to icon
  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'youtube': return <Youtube className="w-6 h-6 text-[#FF0000]" />;
      case 'telegram': return <TelegramIcon className="w-6 h-6 text-[#179CDE]" />;
      case 'tiktok': return <Video className="w-6 h-6 text-[#EE1D52]" />;
      case 'twitch': return <Twitch className="w-6 h-6 text-[#9146FF]" />;
      case 'instagram': return <Instagram className="w-6 h-6 text-[#E1306C]" />;
      case 'facebook': return <Facebook className="w-6 h-6 text-[#1877F2]" />;
      case 'discord': return <MessageSquare className="w-6 h-6 text-[#5865F2]" />;
      case 'snapchat': return <Ghost className="w-6 h-6 text-[#FFFC00] fill-current" />;
      case 'twitter': return <Twitter className="w-6 h-6 text-[#1DA1F2]" />;
      default: return <Globe className="w-6 h-6 text-slate-400" />;
    }
  };

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(channel.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const handleChannelClick = () => {
    onTrackClick(channel.id, channel.url);
  };

  // Generate a mock QR-Code grid pattern for aesthetic layout and representation
  const renderMockQR = () => {
    // Semi-deterministic visual grid based on channel ID and name
    const idNum = channel.id.split('-')[1] || '0';
    const numVal = parseInt(idNum) || 5;
    const gridRows = 16;
    const gridCols = 16;
    const dots = [];

    for (let r = 0; r < gridRows; r++) {
      const rowDots = [];
      for (let c = 0; c < gridCols; c++) {
        // Preset finder patterns in corners
        const isFinderPattern = 
          (r < 4 && c < 4) || // Top-Left
          (r < 4 && c >= gridCols - 4) || // Top-Right
          (r >= gridRows - 4 && c < 4); // Bottom-Left
        
        let active = false;
        if (isFinderPattern) {
          // Inner/outer borders of finder square
          const isOuter = r === 0 || r === 3 || c === 0 || c === 3 || 
                          r === 0 || r === 3 || c === gridCols - 1 || c === gridCols - 4 ||
                          r === gridRows - 1 || r === gridRows - 4 || c === 0 || c === 3;
          const isInner = (r === 1 && c === 1) || (r === 2 && (c === 1 || c === 2)) ||
                          (r === 1 && c === gridCols - 2) || (r === 2 && (c === gridCols - 2 || c === gridCols - 3)) ||
                          (r === gridRows - 2 && c === 1) || (r === gridRows - 3 && (c === 1 || c === 2));
          active = isOuter || isInner;
        } else {
          // Alternate dots based on simple calculation
          active = ((r * numVal + c * 7) % 3 === 0) || ((r * 29 + c * 13) % 4 === 0);
        }
        rowDots.push(active);
      }
      dots.push(rowDots);
    }

    return (
      <div className="flex flex-col items-center bg-white p-4 rounded-xl shadow-lg border border-slate-200">
        {/* Finder layout */}
        <div className="grid grid-cols-16 gap-0.5 w-36 h-36 bg-white shrink-0 antialiased p-1">
          {dots.map((row, rIdx) => 
            row.map((active, cIdx) => (
              <div 
                key={`${rIdx}-${cIdx}`} 
                className={`w-full aspect-square transition-all duration-300 ${active ? 'bg-slate-900' : 'bg-transparent'}`}
                style={{ borderRadius: active ? '1px' : '0' }}
              />
            ))
          )}
        </div>
        <p className="text-[10px] font-mono mt-2 text-slate-500 text-center select-none truncate max-w-[150px]">
          {channel.url}
        </p>
        <span className="text-[10px] text-amber-500 font-medium mt-1 animate-pulse">
          {t.scanQR}
        </span>
      </div>
    );
  };

  const isRtl = language === 'ckb';

  return (
    <motion.div
      id={`channel-card-${channel.id}`}
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -6, scale: 1.01 }}
      onClick={handleChannelClick}
      className="relative overflow-hidden rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 hover:border-white/20 p-6 flex flex-col justify-between transition-all duration-300 shadow-[0_0_30px_rgba(0,0,0,0.3)] group cursor-pointer"
    >
      {/* Decorative top pulse glow mapped to channel custom color */}
      <div 
        className="absolute top-0 left-0 right-0 h-[3px] transition-all duration-300 opacity-60 group-hover:opacity-100"
        style={{ backgroundColor: channel.accentColor || '#3B82F6' }}
      />
      <div 
        className="absolute -top-12 -left-12 w-28 h-28 rounded-full filter blur-2xl opacity-10 transition-all duration-500 group-hover:opacity-20 pointer-events-none animate-pulse"
        style={{ backgroundColor: channel.accentColor || '#3B82F6' }}
      />

      <div className="flex flex-col gap-4">
        {/* Card Header information */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-4">
            <div 
              className="p-3 rounded-2xl border flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-105"
              style={{ 
                backgroundColor: `${channel.accentColor || '#3B82F6'}1a`,
                borderColor: `${channel.accentColor || '#3B82F6'}33`,
                boxShadow: `0 4px 14px rgba(0, 0, 0, 0.4)`
              }}
            >
              {getPlatformIcon(channel.platform)}
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-white text-lg leading-snug truncate transition-colors group-hover:text-indigo-200">
                {channel.name}
              </h3>
              <p className="text-xs font-mono text-gray-500 mt-0.5 truncate select-all">
                {channel.handle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isAdminMode && (
              <>
                <button
                  id={`btn-edit-${channel.id}`}
                  onClick={(e) => { e.stopPropagation(); onEdit(channel); }}
                  className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition-colors cursor-pointer"
                  title={t.editChannel}
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  id={`btn-delete-${channel.id}`}
                  onClick={(e) => { e.stopPropagation(); onDelete(channel.id); }}
                  className="p-1.5 rounded-xl bg-white/5 hover:bg-rose-950/80 text-rose-400 hover:text-rose-200 border border-white/5 hover:border-rose-900/50 transition-colors cursor-pointer"
                  title={t.delete}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Card Description */}
        <p className="text-sm text-gray-400 leading-relaxed break-words min-h-[42px]">
          {channel.description || "No description provided for this link."}
        </p>

        {/* Stats view & Category Badge */}
        <div className="flex items-center justify-between border-t border-white/5 pt-3.5 mt-1">
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-white/5 text-gray-400 border border-white/5 uppercase tracking-wider">
            {displayCategory}
          </span>
          <div className="flex items-center gap-1.5 text-xs text-gray-500 font-mono">
            <MousePointerClick className="w-3.5 h-3.5 text-gray-650" />
            <span>
              {channel.clicks} {t.clicks}
            </span>
          </div>
        </div>
      </div>

      {/* Button interface for interactions */}
      <div className="mt-5 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          {/* Active direct opening link */}
          <a
            id={`btn-open-${channel.id}`}
            href={channel.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => { e.stopPropagation(); handleChannelClick(); }}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl font-bold text-sm transition-all duration-300 cursor-pointer text-[#050508] shadow-lg group/btn hover:brightness-110"
            style={{ 
              backgroundColor: channel.accentColor || '#3B82F6',
              boxShadow: `0 4px 20px -5px ${channel.accentColor || '#3B82F6'}`
            }}
          >
            <span>{t.visit}</span>
            <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
          </a>

          {/* Quick Copy Link */}
          <button
            id={`btn-copy-${channel.id}`}
            onClick={handleCopy}
            className={`p-3 rounded-2xl border transition-all duration-200 cursor-pointer ${
              copied 
                ? 'bg-emerald-950/80 border-emerald-900 text-emerald-400' 
                : 'bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10'
            }`}
            title={t.copy}
          >
            {copied ? <Check className="w-4 h-4 animate-scale" /> : <Copy className="w-4 h-4" />}
          </button>

          {/* QR Code utility button */}
          <button
            id={`btn-qr-${channel.id}`}
            onClick={(e) => { e.stopPropagation(); setShowQR(!showQR); }}
            className={`p-3 rounded-2xl border transition-all duration-200 cursor-pointer ${
              showQR
                ? 'bg-indigo-950/80 border-indigo-905 text-indigo-400 animate-pulse'
                : 'bg-white/5 border-white/10 text-gray-400 hover:text-white hover:bg-white/10'
            }`}
            title={t.qrCode}
          >
            <QrCode className="w-4 h-4" />
          </button>
        </div>

        {/* QR Code expansion block */}
        <AnimatePresence>
          {showQR && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mt-1"
            >
              <div className="pt-2.5 flex flex-col items-center">
                {renderMockQR()}
                <button
                  id={`btn-close-qr-${channel.id}`}
                  onClick={(e) => { e.stopPropagation(); setShowQR(false); }}
                  className="mt-2 text-[11px] text-gray-500 hover:text-gray-300 cursor-pointer hover:underline"
                >
                  [{t.closeQR}]
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};
