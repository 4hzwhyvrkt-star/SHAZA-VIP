/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Channel, CreatorProfile, Category } from '../types';
import shazaLogo from '../assets/images/shaza_vip_logo_1780588907015.png';
import shazaCover from '../assets/images/shaza_vip_cover_1780588929185.png';

export const initialCategories: Category[] = [
  { id: 'all', labelEn: 'All Hubs', labelCkb: 'هەموو بەستەرەکان' },
  { id: 'gaming', labelEn: 'Gaming & Streams', labelCkb: 'گەمینگ و پەخش' },
  { id: 'socials', labelEn: 'Social Outlets', labelCkb: 'تۆڕە کۆمەڵایەتییەکان' },
  { id: 'chat', labelEn: 'Chat & Community', labelCkb: 'گفتوگۆ و کۆمەڵگە' },
  { id: 'content', labelEn: 'Clips & Short Videos', labelCkb: 'کلیپ و ڤیدیۆکان' },
  { id: 'key', labelEn: 'Keys & Licenses', labelCkb: 'کلیل' },
  { id: 'tutorial', labelEn: 'Tutorials', labelCkb: 'فێرکاری' },
  { id: 'official', labelEn: 'Official Account', labelCkb: 'ئەکاونتی فەرمی' }
];

export const initialProfile: CreatorProfile = {
  displayName: "SHAZA VIP",
  username: "Hamokal4ri",
  bio: "درام بەتڵگراوندس و گەمینگ • Gaming content creator Specializing in Battle Royale & Community Tournaments. Connect with me across my official hubs!",
  avatarUrl: shazaLogo,
  coverUrl: shazaCover,
  verified: true,
  views: 0
};

export const defaultChannels: Channel[] = [
  {
    id: 'ch-1',
    name: 'SHAZA VIP - CHANEL',
    handle: '@shazavip_chanel',
    platform: 'telegram',
    url: 'https://t.me/shazavip',
    description: 'چەناڵی فەرمی',
    clicks: 0,
    category: 'gaming',
    accentColor: '#3B82F6' // Telegram Blue
  },
  {
    id: 'ch-2',
    name: 'SHAZA VIP - KEY',
    handle: '@shazavip_key',
    platform: 'telegram',
    url: 'https://t.me/shazavip1',
    description: 'چەناڵی کلیل',
    clicks: 0,
    category: 'key',
    accentColor: '#3B82F6' // Telegram Blue
  },
  {
    id: 'ch-3',
    name: 'SHAZA VIP - CHAT',
    handle: '@shazavip2',
    platform: 'telegram',
    url: 'https://t.me/shazavip2',
    description: 'گروپ چات',
    clicks: 0,
    category: 'chat',
    accentColor: '#3B82F6' // Telegram Blue
  },
  {
    id: 'ch-4',
    name: 'SHAZA VIP - TUT',
    handle: '@shazavip3',
    platform: 'telegram',
    url: 'https://t.me/shazavip3',
    description: 'چەناڵی فێرکاری',
    clicks: 0,
    category: 'tutorial',
    accentColor: '#3B82F6' // Telegram Blue
  },
  {
    id: 'ch-5',
    name: 'SHAZA VIP - 2',
    handle: '@shazavip5',
    platform: 'telegram',
    url: 'https://t.me/shazavip5',
    description: 'چەناڵی دووەمی فەرمی',
    clicks: 0,
    category: 'gaming',
    accentColor: '#3B82F6' // Telegram Blue
  },
  {
    id: 'ch-6',
    name: 'SHAZA - OFFICIAL',
    handle: '@Hamokal4ri',
    platform: 'telegram',
    url: 'https://t.me/Hamokal4ri',
    description: 'ئەکاونتی فەرمی شازە',
    clicks: 0,
    category: 'official',
    accentColor: '#3B82F6' // Telegram Blue
  }
];
