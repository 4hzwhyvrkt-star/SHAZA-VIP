/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Language } from '../types';

export const translations: Record<Language, Record<string, string>> = {
  en: {
    // General
    title: "My Creative Channels",
    subtitle: "Welcome to my digital space. Check out my official channels and platforms below.",
    searchPlaceholder: "Search channels, handles, or topics...",
    all: "All Channels",
    categories: "Categories",
    noChannels: "No channels found matching your search.",
    addChannel: "Add Channel",
    editChannel: "Edit Channel",
    editProfile: "Edit Profile",
    saveChanges: "Save Changes",
    cancel: "Cancel",
    delete: "Delete",
    resetDefaults: "Reset to Default Templates",
    clickCount: "Clicks",
    clicks: "Clicks",
    visit: "Open Channel",
    copy: "Copy Link",
    copied: "Copied!",
    qrCode: "QR Code",
    scanQR: "Scan to visit on mobile",
    closeQR: "Close QR",
    stats: "Link Statistics",
    totalClicks: "Total Clicks",
    totalChannels: "Total Channels",
    profileViews: "Profile Views",
    
    // Form Labels
    channelName: "Channel Name",
    channelUrl: "Channel URL (e.g. https://...)",
    channelHandle: "Handle/Username (e.g. @spardagaming)",
    platform: "Platform",
    channelCategory: "Category",
    accentColor: "Accent Color",
    description: "Brief Description",
    
    // Profile Edit Form
    displayName: "Display Name",
    username: "Username / Tag",
    bio: "Bio Description",
    avatarUrl: "Avatar Image URL",
    coverUrl: "Cover Image URL",
    verified: "Display Verified Badge",
    
    // Messages
    requiredField: "This field is required",
    invalidUrl: "Please enter a valid URL (starting with http:// or https://)",
    confirmDelete: "Are you sure you want to delete this channel?",
    confirmReset: "Are you sure you want to restore the default channels? Your local edits will be replaced.",
    savedSuccess: "Changes saved successfully!",
    addedSuccess: "New channel added successfully!",
    deletedSuccess: "Channel removed successfully!",
    
    // App Header settings
    currentLang: "Language",
    themeMode: "Aesthetic Theme",
    proMode: "Creator Mode"
  },
  ckb: {
    // General
    title: "چەناڵ و پلاتفۆرمەکانم",
    subtitle: "بەخێربێیت بۆ جیهانی دیجیتاڵیم. لە ڕێگەی بەستەرەکانی خوارەوە دەتوانیت کارەکانم ببینی.",
    searchPlaceholder: "بگەڕێ لە چەناڵەکان، یوزەرنەیمەکان، یان بوارەکان...",
    all: "هەموو چەناڵەکان",
    categories: "بوارەکان",
    noChannels: "هیچ چەناڵێک نەدۆزرایەوە کە لەگەڵ گەڕانەکەت بگونجێت.",
    addChannel: "زیادکردنی چەناڵ",
    editChannel: "دەستکاریکردنی چەناڵ",
    editProfile: "دەستکاریکردنی پڕۆفایل",
    saveChanges: "پاشەکەوتکردنی گۆڕانکارییەکان",
    cancel: "پاشگەزبوونەوە",
    delete: "سڕینەوە",
    resetDefaults: "گەڕاندنەوە بۆ چەناڵە بنەڕەتییەکان",
    clickCount: "کلیکەکان",
    clicks: "کلیک",
    visit: "سەردانکردن",
    copy: "کۆپیکردنی بەستەر",
    copied: "کۆپی کرا!",
    qrCode: "کۆدی QR",
    scanQR: "کۆدی QR کۆپی بکە یان سکان بکە بۆ سەردانیکردن",
    closeQR: "داخستنی QR",
    stats: "ئاماری بەستەرەکان",
    totalClicks: "کۆی گشتی کلیکەکان",
    totalChannels: "ژمارەی پلاتفۆرمەکان",
    profileViews: "بینینی پڕۆفایل",
    
    // Form Labels
    channelName: "ناوی چەناڵ / بەستەر",
    channelUrl: "بەستەری چەناڵ (بۆ نموونە https://...)",
    channelHandle: "ناوی بەکارهێنەر / یوزەر (بۆ نموونە spardagaming@)",
    platform: "پلاتفۆرم",
    channelCategory: "بۆلێن و پۆل",
    accentColor: "ڕەنگی دیاریکەر",
    description: "کورتەیەک دەربارەی چەناڵەکە",
    
    // Profile Edit Form
    displayName: "ناوی نیشاندراو",
    username: "نازناو / یوزەر",
    bio: "کورتەی پڕۆفایل (بایۆ)",
    avatarUrl: "بەستەری وێنەی پڕۆفایل",
    coverUrl: "بەستەری وێنەی بەرگ (کۆڤەر)",
    verified: "نیشاندانی نیشانەی باوەڕپێکراو",
    
    // Messages
    requiredField: "پڕکردنەوەی ئەم خانەیە ناچارییە",
    invalidUrl: "تکایە بەستەرێکی دروست بنووسە (دەستپێبکات بە http:// یان https://)",
    confirmDelete: "دڵنیای لە سڕینەوەی ئەم چەناڵە؟",
    confirmReset: "دڵنیای لە گەڕاندنەوەی زانیارییە بنەڕەتییەکان؟ هەموو گۆڕانکارییەکانت تێکدەچن.",
    savedSuccess: "گۆڕانکارییەکان بە سەرکەوتوویی پاشەکەوت کران!",
    addedSuccess: "چەناڵی نوێ بە سەرکەوتوویی زیادکرا!",
    deletedSuccess: "چەناڵەکە بە سەرکەوتوویی سڕایەوە!",
    
    // App Header settings
    currentLang: "زمان",
    themeMode: "ستایل و ڕەنگ",
    proMode: "دۆخی دروستکەر"
  }
};
