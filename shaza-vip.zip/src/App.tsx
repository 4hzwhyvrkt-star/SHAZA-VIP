/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Search, 
  RefreshCw, 
  Sparkles, 
  Compass, 
  ArrowRight,
  ShieldCheck,
  Eye,
  Settings
} from 'lucide-react';
import { Language, Channel, CreatorProfile } from './types';
import { initialCategories, initialProfile, defaultChannels } from './utils/initialData';
import { translations } from './utils/translations';
import { ProfileHeader } from './components/ProfileHeader';
import { ChannelCard } from './components/ChannelCard';
import { AddChannelModal } from './components/AddChannelModal';
import { EditProfileModal } from './components/EditProfileModal';

export default function App() {
  // 1. Core States
  const [language, setLanguage] = useState<Language>('ckb'); // Default to Kurdish since user requested in Kurdish
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Modals visibility states
  const [isAddOpen, setIsAddOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [editingChannel, setEditingChannel] = useState<Channel | null>(null);

  // 2. Persistent States through LocalStorage
  const [profile, setProfile] = useState<CreatorProfile>(() => {
    const saved = localStorage.getItem('creator_profile');
    return saved ? JSON.parse(saved) : initialProfile;
  });

  const [channels, setChannels] = useState<Channel[]>(() => {
    const saved = localStorage.getItem('creator_channels');
    return saved ? JSON.parse(saved) : defaultChannels;
  });

  // Save changes automatically on update
  useEffect(() => {
    localStorage.setItem('creator_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('creator_channels', JSON.stringify(channels));
  }, [channels]);

  // Synchronize dynamic stats with backend server
  const syncWithServerStats = (stats: { views: number; clicks: { [id: string]: number } }) => {
    setProfile(prev => ({
      ...prev,
      views: stats.views
    }));
    setChannels(prev => prev.map(ch => ({
      ...ch,
      clicks: stats.clicks[ch.id] || 0
    })));
  };

  // Real-time backend stats tracker
  useEffect(() => {
    // Record view immediately on load, and get synced stats
    fetch('/api/stats/view', { method: 'POST' })
      .then(res => res.json())
      .then(stats => {
        syncWithServerStats(stats);
      })
      .catch(err => console.error('Error fetching/incrementing views', err));

    // Poll backend for live clicks/views updates from other users every 5 seconds
    const interval = setInterval(() => {
      fetch('/api/stats')
        .then(res => res.json())
        .then(stats => {
          syncWithServerStats(stats);
        })
        .catch(err => console.error('Error polling stats', err));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const t = translations[language];

  // 3. Operations & Handlers
  const handleSaveChannel = (savingChannel: Channel) => {
    const exists = channels.some(ch => ch.id === savingChannel.id);
    if (exists) {
      setChannels(prev => prev.map(ch => ch.id === savingChannel.id ? savingChannel : ch));
    } else {
      setChannels(prev => [savingChannel, ...prev]);
    }
  };

  const handleDeleteChannel = (id: string) => {
    if (window.confirm(t.confirmDelete)) {
      setChannels(prev => prev.filter(ch => ch.id !== id));
    }
  };

  const handleEditChannelClick = (channel: Channel) => {
    setEditingChannel(channel);
    setIsAddOpen(true);
  };

  const handleAddChannelClick = () => {
    setEditingChannel(null);
    setIsAddOpen(true);
  };

  const handleResetDefaults = () => {
    if (window.confirm(t.confirmReset)) {
      setChannels(defaultChannels);
      setProfile(initialProfile);
      setSelectedCategory('all');
      setSearchQuery('');

      // Also reset server statistics
      fetch('/api/stats/reset', { method: 'POST' })
        .then(res => res.json())
        .then(stats => {
          syncWithServerStats(stats);
        })
        .catch(err => console.error('Error resetting stats on server', err));
    }
  };

  // Click Statistics tracker
  const handleTrackClick = (id: string, url: string) => {
    // Optimistic local update for maximum responsiveness
    setChannels(prev => prev.map(ch => {
      if (ch.id === id) {
        return { ...ch, clicks: ch.clicks + 1 };
      }
      return ch;
    }));

    // Post update to shared server API
    fetch(`/api/stats/click/${id}`, { method: 'POST' })
      .then(res => res.json())
      .then(stats => {
        syncWithServerStats(stats);
      })
      .catch(err => console.error('Error tracking click on server', err));
  };

  const handleSaveProfile = (updatedProfile: CreatorProfile) => {
    setProfile(updatedProfile);
  };

  // 4. Computed Statistics
  const totalClicksCount = useMemo(() => {
    return channels.reduce((sum, ch) => sum + ch.clicks, 0);
  }, [channels]);

  // 5. Searching & Filtering logic
  const filteredChannels = useMemo(() => {
    return channels.filter(channel => {
      // Category filter match
      const categoryMatch = selectedCategory === 'all' || channel.category === selectedCategory;
      
      // Query search match
      const query = searchQuery.trim().toLowerCase();
      if (!query) return categoryMatch;

      const nameMatch = channel.name.toLowerCase().includes(query);
      const handleMatch = channel.handle.toLowerCase().includes(query);
      const categoryLabelMatch = channel.category.toLowerCase().includes(query);
      const descriptionMatch = channel.description?.toLowerCase().includes(query);

      return categoryMatch && (nameMatch || handleMatch || categoryLabelMatch || descriptionMatch);
    });
  }, [channels, selectedCategory, searchQuery]);

  const isRtl = language === 'ckb';

  return (
    <div 
      id="main-app-container"
      className="min-h-screen bg-[#050508] text-white flex flex-col font-sans transition-all selection:bg-purple-600/50 selection:text-white"
      style={{ direction: isRtl ? 'rtl' : 'ltr' }}
    >
      {/* Immersive Atmospheric Glowing Lights */}
      <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-purple-900/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-900/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[30%] left-[30%] w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container Workspace */}
      <main className="flex-grow w-full max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-10 z-10 relative">
        
        {/* Profile Card Header Block */}
        <ProfileHeader
          profile={profile}
          language={language}
          setLanguage={setLanguage}
          isAdminMode={isAdminMode}
          setIsAdminMode={setIsAdminMode}
          channelsCount={channels.length}
          totalClicksCount={totalClicksCount}
          onEditProfile={() => setIsProfileOpen(true)}
        />

        {/* Channels Search and Toolbar */}
        <div id="toolbar-wrapper" className="mb-8 flex flex-col gap-5">
          
          {/* Headline Indicator */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2.5">
              <Compass className="w-5 h-5 text-indigo-400 animate-pulse" />
              <h2 className="text-xl font-bold text-white tracking-tight">
                {t.title}
              </h2>
            </div>

            {/* Admin control panel operations */}
            <div className="flex items-center gap-2">
              {isAdminMode && (
                <button
                  id="btn-add-new-channel"
                  onClick={handleAddChannelClick}
                  className="flex items-center gap-1.5 px-4.5 py-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs transition-all cursor-pointer shadow-lg shadow-indigo-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addChannel}</span>
                </button>
              )}

              {/* Reset state button to pristine defaults */}
              <button
                id="btn-reset-default-templates"
                onClick={handleResetDefaults}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5 text-xs font-semibold cursor-pointer transition-all"
                title={t.resetDefaults}
              >
                <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
                <span>{language === 'ckb' ? 'گەڕاندنەوە' : 'Reset Hub'}</span>
              </button>
            </div>
          </div>

          {/* Dynamic Category Filtering Bar */}
          <div className="overflow-x-auto scrollbar-none py-1 flex items-center gap-2 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
            {initialCategories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              // Compute dynamic counts per category for better depth
              const count = cat.id === 'all' 
                ? channels.length 
                : channels.filter(ch => ch.category === cat.id).length;

              return (
                <button
                  id={`btn-category-tab-${cat.id}`}
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center gap-2.5 px-4.5 py-2 rounded-2xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
                    isActive 
                      ? 'bg-white text-[#050508] font-bold shadow-xl' 
                      : 'bg-white/5 text-gray-400 hover:text-white border border-white/5 hover:bg-white/10'
                  }`}
                >
                  <span>{isRtl ? cat.labelCkb : cat.labelEn}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                    isActive ? 'bg-[#050508] text-white' : 'bg-white/10 text-gray-400'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Live search input field with icon */}
          <div className="relative">
            <span className="absolute inset-y-0 left-4.5 flex items-center pointer-events-none text-gray-500">
              <Search className="w-4.5 h-4.5" />
            </span>
            <input
              id="input-live-search"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-11 pr-4.5 py-3.5 rounded-2xl bg-white/5 border border-white/10 focus:border-white/25 focus:ring-1 focus:ring-white/15 outline-none text-sm transition-all text-white placeholder-gray-505"
            />
            {searchQuery && (
              <button
                id="btn-clear-search-query"
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-4.5 flex items-center text-xs text-gray-400 hover:text-white cursor-pointer"
              >
                [{isRtl ? 'پاککردنەوە' : 'Clear'}]
              </button>
            )}
          </div>
        </div>

        {/* Interactive Alerts / Instructions Banners */}
        {isAdminMode && (
          <div className="mb-6 p-4.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs sm:text-sm flex items-start gap-3 w-full">
            <ShieldCheck className="w-5.5 h-5.5 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <p className="font-bold text-amber-300">{language === 'ckb' ? 'تۆ ئێستا لە دۆخی دەستکاریکردنی پڕۆفایلدایت!' : 'You are currently in Creator Mode!'}</p>
              <p className="mt-1 text-amber-400/90 font-normal leading-relaxed">
                {language === 'ckb' 
                  ? 'دەتوانیت کورتە پڕۆفایل، بەستەرەکان، و وێنەکان بگۆڕیت، پاشەکەوت دەبن لەناو وێبگەڕەکەتدا بە شێوەی خۆکار.'
                  : 'You can freely add, modify or remove channel entries and update profile components. Changes persist in your local browser.'}
              </p>
            </div>
          </div>
        )}

        {/* 6. Channels grid listing */}
        <AnimatePresence mode="popLayout">
          {filteredChannels.length > 0 ? (
            <motion.div 
              id="channels-grid-layout"
              layout
              className="grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6"
            >
              {filteredChannels.map((channel) => (
                <ChannelCard
                  key={channel.id}
                  channel={channel}
                  language={language}
                  isAdminMode={isAdminMode}
                  onEdit={handleEditChannelClick}
                  onDelete={handleDeleteChannel}
                  onTrackClick={handleTrackClick}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              id="empty-results-banner"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-14 px-6 text-center border border-dashed border-white/10 rounded-3xl bg-white/5 flex flex-col items-center justify-center gap-3.5"
            >
              <Sparkles className="w-9 h-9 text-gray-600 animate-pulse" />
              <p className="text-gray-400 font-semibold">{t.noChannels}</p>
              <button
                id="btn-reset-filters-on-empty"
                onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-bold underline cursor-pointer"
              >
                {language === 'ckb' ? 'بینینی هەموو بەستەرەکان' : 'View all channels'}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Simple friendly footer conforming to Immersive UI specifications */}
        <footer className="mt-20 pt-8 border-t border-white/5 text-center flex items-center justify-between flex-wrap gap-4 text-xs text-gray-500">
          <div className="flex items-center gap-3">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="uppercase tracking-wider font-extrabold text-[10px] text-gray-450">
              {language === 'ckb' ? 'چالاکە ئێستا' : 'Live Gateway'}
            </span>
          </div>

          <p className="font-semibold text-gray-500">
            {profile.displayName} &copy; 2026 • {language === 'ckb' ? 'هەموو مافەکان پارێزراوە' : 'All Rights Reserved'}
          </p>
        </footer>
      </main>

      {/* 7. Action Add/Edit Modal */}
      <AnimatePresence>
        {isAddOpen && (
          <AddChannelModal
            language={language}
            isOpen={isAddOpen}
            onClose={() => { setIsAddOpen(false); setEditingChannel(null); }}
            onSave={handleSaveChannel}
            editingChannel={editingChannel}
            categories={initialCategories}
          />
        )}
      </AnimatePresence>

      {/* 8. Creator Profile Edit Modal */}
      <AnimatePresence>
        {isProfileOpen && (
          <EditProfileModal
            language={language}
            isOpen={isProfileOpen}
            onClose={() => setIsProfileOpen(false)}
            onSave={handleSaveProfile}
            currentProfile={profile}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
