/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'ckb' | 'en';

export interface Channel {
  id: string;
  name: string;
  handle: string;
  platform: 'youtube' | 'telegram' | 'tiktok' | 'twitch' | 'instagram' | 'facebook' | 'discord' | 'website' | 'snapchat' | 'twitter' | 'custom';
  url: string;
  description: string;
  clicks: number;
  category: string;
  accentColor: string;
  qrCodeVisible?: boolean;
}

export interface CreatorProfile {
  displayName: string;
  username: string;
  bio: string;
  avatarUrl: string;
  coverUrl: string;
  verified: boolean;
  views: number;
}

export interface Category {
  id: string;
  labelEn: string;
  labelCkb: string;
}
