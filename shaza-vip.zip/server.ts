import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json());

// Path to stats persistence file
const STATS_FILE = path.join(process.cwd(), "stats.json");

interface StatsData {
  views: number;
  clicks: { [channelId: string]: number };
}

// Read current stats from persistence file or initialize them
function loadStats(): StatsData {
  try {
    if (fs.existsSync(STATS_FILE)) {
      const data = fs.readFileSync(STATS_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (error) {
    console.error("Error loading stats, using default initialized data", error);
  }
  return { views: 0, clicks: {} };
}

// Write stats to file asynchronously
function saveStats(stats: StatsData) {
  try {
    fs.writeFileSync(STATS_FILE, JSON.stringify(stats, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing stats to file", error);
  }
}

// API Routes
// 1. Get current views and clicks mapping
app.get("/api/stats", (req, res) => {
  const stats = loadStats();
  res.json(stats);
});

// 2. Increment global profile views
app.post("/api/stats/view", (req, res) => {
  const stats = loadStats();
  stats.views += 1;
  saveStats(stats);
  res.json(stats);
});

// 3. Increment clicks for a specific channel
app.post("/api/stats/click/:id", (req, res) => {
  const id = req.params.id;
  const stats = loadStats();
  if (!stats.clicks[id]) {
    stats.clicks[id] = 0;
  }
  stats.clicks[id] += 1;
  saveStats(stats);
  res.json(stats);
});

// Reset Stats to Zero (for user or system commands if they want to clear stats)
app.post("/api/stats/reset", (req, res) => {
  const freshStats = { views: 0, clicks: {} };
  saveStats(freshStats);
  res.json(freshStats);
});

// Vite Middleware & Static Files
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // Serve index.html for any remaining route in production SPA
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

setupVite();
